﻿using LabelShop;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.ComponentModel;
using System.Drawing.Printing;
using System.Drawing;
using System.Security.Cryptography;
using static LabelShop.TLXLabelPaintCLS;
using System.Web.Http.Cors;
namespace WebApplicationLocalAPI.Controllers
{
    /// <summary>
    /// 测试控制器，自己设置
    /// </summary>
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class testController : ControllerBase
    {
      
        private int handle = 0;     //  用于保存标签模板的句柄
        private string strFileName; //  标签模板文件名称
        List<string> printerstr = new List<string>();
        string strPrinter = "";

        /// <summary>
        ///测试方法getstr
        /// </summary>
        /// <returns></returns>
        [HttpGet(Name = "GetString")]
        [ApiExplorerSettings(GroupName ="v1")]
        public string Getstr()
        {
            return "the first string";
        }

        [HttpGet(Name = "GetString1")]
        [ApiExplorerSettings(GroupName = "v2")]
        public string Getstr1()
        {
            return "the first string1 ";
        }

        [HttpGet(Name = "Initialize")]
        [ApiExplorerSettings(GroupName = "v1")]
        public string Initialize()
        {
            TLXLabelPaintCLS.RET ret;
            TLXLabelPaintCLS.LICENSETYPE license = LICENSETYPE.TLXLP_LICENSE_ENTERPRISE;
            string licensetext="";
            string strPrinter = "";
            ret = TLXLabelPaintCLS.SetLicense("4G9CU-KPYUK-3H2UY-6K79Z-3DQJB");

            //  获取授权状态
            ret = TLXLabelPaintCLS.GetLicense(ref license);

            switch (license)
            {
                case TLXLabelPaintCLS.LICENSETYPE.TLXLP_LICENSE_BASIC:
                    licensetext = "授权模式：标准版";
                    break;
                case TLXLabelPaintCLS.LICENSETYPE.TLXLP_LICENSE_PROFESSIONAL:
                    licensetext = "授权模式：专业版";
                    break;
                case TLXLabelPaintCLS.LICENSETYPE.TLXLP_LICENSE_ENTERPRISE:
                    licensetext = "授权模式：企业版";
                    break;
                case TLXLabelPaintCLS.LICENSETYPE.TLXLP_LICENSE_NONE:
                    licensetext = "授权模式：未授权";
                    break;
            }

            //  系统中的所有打印机
            //foreach (string sPrint in PrinterSettings.InstalledPrinters)
            //    cbPrinters.Items.Add(sPrint);

            //  获取 LabelShop 支持的打印机列表
            //  LabelShop 从 5.30 版本起，支持内置打印机驱动模式，使用 GetSysPrinterNames 接口，可以获取系统中已经安装的此类打印机
            //  需要注意的是，此类打印机在WINDOWS中是不可见的
            //  另外，此类打印机一般是需要在 LabelShop 中手工安装的
            //  但是如果打开的一个标签模板中使用了一台未安装的此类打印机，则系统会自动安装此打印机
            //  因此在打开了一个模板后，可能需要刷新打印机列表

            string strPrinters = "";
            ret = TLXLabelPaintCLS.GetSysPrinterNames(ref strPrinters);

            //  打印机名称是用 \n 分隔开的
            string[] sPrinterArray = strPrinters.Split(new char[] { '\n' });
            foreach (string sPrint in sPrinterArray)
                printerstr.Add(sPrint);


            return licensetext;
        }



        [HttpGet(Name = "getlableurl")]
        [ApiExplorerSettings(GroupName = "v1")]
        public string Getgetlableurlstr1(string labelur)
        {
            TLXLabelPaintCLS.RET ret;
            Initialize();
            string errostr = "no infro";
            string strFileName = "D:\\std_tag.lsdx";

            

            ret = TLXLabelPaintCLS.OpenDocument(strFileName, ref handle);
            if (ret != TLXLabelPaintCLS.RET.TLXLP_OK)
            {
                //MessageBox.Show(ErrorMessage(ret), "出错", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return errostr;
            }

            //  模板文件是否被授权。我们将使用付费版本的 LabelShop 编辑保存的标签模板提前为被授权的标签模板文件
            //  在使用企业版授权模式打印时，需要使用授权的标签模板
            TLXLabelPaintCLS.DOCLEVEL level = TLXLabelPaintCLS.DOCLEVEL.TLXLP_DOCUMENT_BASIC;
            ret = TLXLabelPaintCLS.GetDocumentLevel(handle, ref level);
            
            if (ret != TLXLabelPaintCLS.RET.TLXLP_OK)
            {
                //MessageBox.Show(ErrorMessage(ret), "出错", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return errostr;
            }
            else
            {
                switch (level)
                {
                    case TLXLabelPaintCLS.DOCLEVEL.TLXLP_DOCUMENT_BASIC:
                        string lbDocLevel = "模板授权：未授权的模板";
                        break;
                    case TLXLabelPaintCLS.DOCLEVEL.TLXLP_DOCUMENT_PROFESSIONAL:
                        string  lbDocLevelText = "模板授权：已授权的模板";
                        break;
                }
            }

            /*  关于模板授权状态的特别说明：
                在企业版授权模式下，只有模板授权状态为已授权的标签模板，才可以被接口2正常打印
                而打印未授权的模板时，会被加入特殊的标记

                使用付费版本的LabelShop编辑并保存的模板是已授权的模板，付费的版本包括LabelShop专业版和企业版
                使用免费的LabelShop以及OEM版本的LabelShop编辑的标签模板，是未授权的模板
            */

            /*
             关于标签中的命名变量
             可以通过接口，对标签模板上的命名变量进行赋值，以达到动态设置标签打印内容的目的
             接口允许从标签模板中读出所有的命名变量名称，并分别获取其当前值
             */
            //string strNames = "";
            //ret = TLXLabelPaintCLS.GetNamedVarNames(handle, ref strNames);

            //  命令变量是用 \n 分隔开的
            //string[] sNameArray = strNames.Split(new char[] { '\n' });

            //cbVarNames.Items.Clear();

            //foreach (string sVarName in sNameArray)
            //{
            //    cbVarNames.Items.Add(sVarName);
            //}
            //cbVarNames.SelectedIndex = 0;

            /*
             关于标签略图
             接口支持获取标签模板的略图，以便于显示给用户参考
             */
            //Bitmap bmp = null;
           // ret = TLXLabelPaintCLS.GetThumbnailEx(handle, ref bmp, this.pictureBox1.Size.Width - 2, this.pictureBox1.Size.Height - 2,
              //  TLXLabelPaintCLS.TLXLP_THUMB_WORKSPACECOLOR, 0);

            //  在此处更新打印机列表
            //  LabelShop 从5.30 版本起，支持内置打印机驱动模式，请参考 窗体初始化时相关代码的说明
            //  打开一个新的模板，可能会自动安装一台内置驱动的打印机，因此需要更新打印机列表
            string strPrinters = "";
            ret = TLXLabelPaintCLS.GetSysPrinterNames(ref strPrinters);
            printerstr.Clear();
            //  打印机名称是用 \n 分隔开的
            string[] sPrinterArray = strPrinters.Split(new char[] { '\n' });
            foreach (string sPrint in sPrinterArray)
                printerstr.Add(sPrint);


           
            TLXLabelPaintCLS.GetPrinterName(handle, ref strPrinter);
            PrintDocument print = new PrintDocument();
            string sDefault = print.PrinterSettings.PrinterName;//默认打印机名

            //cbPrinters.Text = strPrinter;
            // if (cbPrinters.SelectedIndex == -1)
            //{
            //  程序不会执行到这里，因为在标签模板打开时，如果没有找到标签模板中记录的打印机，则试图匹配一台近似的打印机，否则自动转换到系统默认打印机上
            //PrintDocument print = new PrintDocument();
            // string sDefault = print.PrinterSettings.PrinterName;//默认打印机名
            // cbPrinters.Text = sDefault;
            // }


            // pictureBox1.Image = bmp;

            return "ok";
        }

        [HttpGet(Name = "printlabel")]
        [ApiExplorerSettings(GroupName = "v1")]
        public string printlabe()
        {
            string strPrinters = "SHARP MX-M2608N PCL6";
            string filename = "D:\\std_tag.lsdx";
            Initialize();
            TLXLabelPaintCLS.RET ret;
            ret = TLXLabelPaintCLS.OpenDocument(filename, ref handle);
           // ret = TLXLabelPaintCLS.GetSysPrinterNames(ref strPrinters);
            if (handle == 0)
                return "no";
           
            /*
                    err 取值
                    0   授权不符时，输出标签，但是标签上会包含额外的标记
                    1   授权不符时，不输出标签
                    2   授权不符时，给出提示，用户选择是否输出标签，如果希望尽量避免输出带额外标记的标签，可以用这个方法提供用户选择的机会
            */
            int qty = int.Parse("1");
            int copy = int.Parse("1");
            //  如果目标打印机不同，请设置目标打印机
            TLXLabelPaintCLS.SetPrinterName(handle, strPrinters);
            ret = TLXLabelPaintCLS.OutputDocument(handle, qty, copy, 0);


            return "ok";
        }

    }
}
