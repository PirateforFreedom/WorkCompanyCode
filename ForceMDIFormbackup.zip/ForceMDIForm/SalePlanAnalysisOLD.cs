﻿using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using NPOI.SS.UserModel;
using NPOI.XSSF.UserModel;
using NPOI.HSSF.UserModel;
using System.Data;
using System.IO;
using System;
using static System.Net.WebRequestMethods;
using System.Reflection.Emit;
using NPOI.SS.Formula.Functions;
using System.Linq;
using NPOI.OpenXmlFormats.Wordprocessing;
using static System.Net.Mime.MediaTypeNames;
using System.Data.SqlClient;
using Org.BouncyCastle.Asn1.X509;
using System.Text.RegularExpressions;

namespace ForceMDIForm
{
    public partial class SalePlanAnalysisOLD : Form
    {
        string savePath = "";
        DataTable dtsources;
        DataTable dttarget;
        DataTable DBdttemp;
        DataTable dttargetCOPY;
        string OrderDate;
        int gcount = 0;
        int cgcount = 0;
        int sumid = 1;
        DateTime date2;
        int filecoutsum = 0;
        double filesumkm = 0.0;
        string consql = @"server=61.152.218.58,14333;database=x3v71sql;uid=readx3;pwd=Force@54321";
        SqlConnection conn;
        public SalePlanAnalysisOLD()
        {
            InitializeComponent();
            InitializeTargetDT();

            date2 = new DateTime();
            conn = new SqlConnection(consql);

        }

        public void InitializeTargetDT()
        {
            dttarget = new DataTable();
            DataColumn? dc = null;
            dc = dttarget.Columns.Add("序号", Type.GetType("System.String"));
            dc.AutoIncrement = true;//自动增加
            dc.AutoIncrementSeed = 1;//起始为1
            dc.AutoIncrementStep = 1;//步长为1
            dc.AllowDBNull = false;//

            dc = dttarget.Columns.Add("备用1", Type.GetType("System.String"));
            dc = dttarget.Columns.Add("备用2", Type.GetType("System.String"));
            dc = dttarget.Columns.Add("FS码", Type.GetType("System.String"));

            dc = dttarget.Columns.Add("零件号2", Type.GetType("System.String"));
            dc = dttarget.Columns.Add("零件号1", Type.GetType("System.String"));
            dc = dttarget.Columns.Add("型号", Type.GetType("System.String"));


            dc = dttarget.Columns.Add("规格", Type.GetType("System.String"));
            dc = dttarget.Columns.Add("导体", Type.GetType("System.String"));
            dc = dttarget.Columns.Add("颜色", Type.GetType("System.String"));
            dc = dttarget.Columns.Add("标识", Type.GetType("System.String"));
            dc = dttarget.Columns.Add("订单数量", Type.GetType("System.String"));
            dc = dttarget.Columns.Add("库存数量", Type.GetType("System.String"));


            dc = dttarget.Columns.Add("需生产数量", Type.GetType("System.String"));
            dc = dttarget.Columns.Add("识别号", Type.GetType("System.String"));
            dc = dttarget.Columns.Add("客户号", Type.GetType("System.String"));
            dc = dttarget.Columns.Add("计划号", Type.GetType("System.String"));
            dc = dttarget.Columns.Add("合同号", Type.GetType("System.String"));
            dc = dttarget.Columns.Add("交货日期", Type.GetType("System.DateTime"));


            dc = dttarget.Columns.Add("订单日期", Type.GetType("System.DateTime"));
            dc = dttarget.Columns.Add("铜重", Type.GetType("System.String"));
            dc = dttarget.Columns.Add("绝缘重量", Type.GetType("System.String"));
            dc = dttarget.Columns.Add("最小包装量", Type.GetType("System.String"));
            dc = dttarget.Columns.Add("包装方式", Type.GetType("System.String"));

            dc = dttarget.Columns.Add("订单校验结果", Type.GetType("System.String"));
        }

        
        /// <summary>
        /// Excel导入成DataTble
        /// </summary>
        /// <param name="file">导入路径(包含文件名与扩展名)</param>
        /// <returns></returns>
        public DataTable ExcelToTable(string file)
        {
            gcount = 0;
            DataTable dt = new DataTable();
            IWorkbook workbook;
            string fileExt = Path.GetExtension(file).ToLower();
            using (FileStream fs = new FileStream(file, FileMode.Open, FileAccess.Read))
            {
                if (fileExt == ".xlsx")
                {
                    workbook = new XSSFWorkbook(fs);
                }
                else if (fileExt == ".xls")
                {
                    workbook = new HSSFWorkbook(fs);
                }
                else
                {
                    workbook = null;
                }
                if (workbook == null)
                {
                    return null;
                }
                ISheet sheet = workbook.GetSheetAt(0);
                try
                {
                    DateTime date1 = new DateTime();

                    ICell cell = sheet.GetRow(4).GetCell(18);
                    if (cell.CellType == CellType.Numeric)
                    {

                        date1 = cell.DateCellValue;

                    }

                    date2 = date1;
                }
                catch
                {


                }


                //表头  
                IRow header = sheet.GetRow(5);
                List<int> columns = new List<int>();
                for (int i = 0; i < header.LastCellNum; i++)
                {
                    object obj = GetValueType(header.GetCell(i));
                    if (obj == null || obj.ToString() == string.Empty)
                    {
                        dt.Columns.Add(new DataColumn("Columns" + i.ToString()));
                    }
                    else
                        dt.Columns.Add(new DataColumn(obj.ToString()));
                    columns.Add(i);
                }
                //数据  
                for (int i = 5 + 1; i < sheet.LastRowNum - 4; i++)
                {
                    DataRow dr = dt.NewRow();
                    bool hasValue = false;
                    gcount++;


                    dr[0] = gcount;
                    int j = 1;
                    for (j = 1; j < columns.Count; j++)
                    {
                        try
                        {
                            if (columns.IndexOf(j) == dt.Columns.IndexOf("客户代码") + 3)
                            {
                                dr[j] = sheet.GetRow(i).GetCell(j).DateCellValue;
                                hasValue = true;
                                continue;
                            }
                        }
                        catch
                        {

                        }
                        try
                        {
                            if (sheet.GetRow(i).GetCell(j).CellType == CellType.Formula)
                            {
                                sheet.GetRow(i).GetCell(j).SetCellType(CellType.String);
                                dr[j] = sheet.GetRow(i).GetCell(j).StringCellValue;
                                hasValue = true;
                                continue;
                            }
                        }
                        catch
                        {

                        }


                        dr[j] = GetValueType(sheet.GetRow(i).GetCell(j));
                        if (dr[j] != null && dr[j].ToString() != string.Empty)
                        {
                            hasValue = true;
                        }
                    }


                    if (hasValue)
                    {
                        dt.Rows.Add(dr);
                    }
                }
            }
            return dt;
        }

        /// <summary>
        /// 获取单元格类型
        /// </summary>
        /// <param name="cell">目标单元格</param>
        /// <returns></returns>
        private static object GetValueType(ICell cell)
        {
            if (cell == null)
                return null;
            switch (cell.CellType)
            {
                case CellType.Blank:
                    return null;
                case CellType.Boolean:
                    return cell.BooleanCellValue;
                case CellType.Numeric:
                    return cell.NumericCellValue;
                case CellType.String:
                    return cell.StringCellValue;
                case CellType.Error:
                    return cell.ErrorCellValue;
                case CellType.Formula:
                default:
                    return "=" + cell.CellFormula;
            }
        }



        public DataTable MergeTable(DataTable dt)
        {
            double numtemp = 0.0;
            string flagerp = "YES";
            string ForceDecrib = "";
            double numsums1 = 0.0;
            for (int i = 0; i < dt.Rows.Count; i++)
            {

                try
                {
                    if (dt.Rows[i][dt.Columns.IndexOf("标识") - 1].ToString() == "")
                    {
                        continue;
                    }

                }
                catch
                {

                    continue;
                }

                string lingjianhao = "检查是否是零件号1";
                try
                {
                    lingjianhao = dt.Rows[i]["零件号1"].ToString();
                }
                catch
                {
                    lingjianhao = dt.Rows[i]["零件号"].ToString();
                }
                try
                {
                    DBdttemp = SqlQuery(" where ITM.ITMREF_0='" + dt.Rows[i]["FS码"].ToString() + "' and YITM.YBPCNUM_0='" + dt.Rows[i]["客户代码"].ToString() + "' and YITM.YITMREFBPC_0='" + lingjianhao + "' ");

                    if (DBdttemp.Rows.Count <= 0)
                    {
                        flagerp = "NO";


                    }
                    else
                    {
                        ForceDecrib = DBdttemp.Rows[0][1].ToString();
                    }
                }
                catch

                {
                    flagerp = "unkonwn";
                    ForceDecrib = "";
                }


                int p_int_num;

                try
                {
                    if (int.TryParse(dt.Rows[i][0].ToString(), out p_int_num) && dt.Rows[i]["型号"].ToString() != "" && dt.Rows[i][dt.Columns.IndexOf("标识") + 1].ToString() != "")
                    {

                        DataRow newRow;
                        newRow = dttarget.NewRow();
                        newRow["序号"] = sumid.ToString();
                        newRow["订单日期"] = date2;
                        newRow["FS码"] = dt.Rows[i]["FS码"].ToString();
                        newRow["零件号2"] = ForceDecrib;
                        newRow["零件号1"] = lingjianhao;
                        newRow["型号"] = dt.Rows[i]["型号"].ToString();
                        newRow["规格"] = dt.Rows[i][dt.Columns.IndexOf("型号") + 1].ToString();
                        newRow["导体"] = dt.Rows[i][dt.Columns.IndexOf("型号") + 2].ToString();
                        newRow["颜色"] = dt.Rows[i][dt.Columns.IndexOf("型号") + 3].ToString();
                        newRow["标识"] = dt.Rows[i][dt.Columns.IndexOf("标识")].ToString();
                        newRow["订单数量"] = dt.Rows[i][dt.Columns.IndexOf("标识") + 1].ToString();

                        try
                        {

                            numtemp = Double.Parse(dt.Rows[i][dt.Columns.IndexOf("标识") + 2].ToString());
                        }
                        catch
                        {

                            numtemp = 0.0;
                        }
                        newRow["库存数量"] = numtemp;

                        try
                        {

                            numsums1 = System.Convert.ToDouble(dt.Rows[i][dt.Columns.IndexOf("标识") + 1].ToString());
                        }
                        catch
                        {
                            numsums1 = 0.0;
                        }
                        newRow["需生产数量"] = numsums1 - numtemp;
                        newRow["识别号"] = dt.Rows[i][dt.Columns.IndexOf("客户代码") - 1].ToString();
                        newRow["客户号"] = dt.Rows[i][dt.Columns.IndexOf("客户代码")].ToString();
                        newRow["计划号"] = dt.Rows[i][dt.Columns.IndexOf("客户代码") + 1].ToString();
                        newRow["合同号"] = dt.Rows[i][dt.Columns.IndexOf("客户代码") + 2].ToString();
                        newRow["交货日期"] = dt.Rows[i][dt.Columns.IndexOf("客户代码") + 3];
                        newRow["最小包装量"] = dt.Rows[i][dt.Columns.IndexOf("包装方式") - 1].ToString();
                        newRow["包装方式"] = dt.Rows[i]["包装方式"].ToString();
                        newRow["订单校验结果"] = flagerp;
                        dttarget.Rows.Add(newRow);
                        sumid++;
                    }
                }
                catch

                {
                    continue;
                }

            }

            return dttarget;

        }


        /// <summary>
        /// Datable导出成Excel(xlsx)
        /// </summary>
        /// <param name="dt"></param>
        /// <param name="file">导出路径(包括文件名与扩展名)</param>
        public static void TableToExcel(DataTable dt, string file)
        {


            IWorkbook workbook;
            workbook = new XSSFWorkbook();
            string fileExt = Path.GetExtension(file).ToLower();
            if (workbook == null) { return; }

            ISheet sheet = string.IsNullOrEmpty(dt.TableName) ? workbook.CreateSheet("sheet0") : workbook.CreateSheet(dt.TableName);
            //表头  
            IRow row = sheet.CreateRow(0);
            for (int i = 0; i < dt.Columns.Count - 1; i++)
            {
                ICell cell = row.CreateCell(i);
                cell.SetCellValue(dt.Columns[i].ColumnName);
            }

            //数据  
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                IRow row1 = sheet.CreateRow(i + 1);
                for (int j = 0; j < dt.Columns.Count - 1; j++)
                {
                    ICell cell = row1.CreateCell(j);

                    try
                    {
                        cell.SetCellValue(Convert.ToDouble(dt.Rows[i][j].ToString()));
                    }
                    catch
                    {

                        if (dt.Rows[i][j].GetType() == Type.GetType("System.DateTime"))
                        {
                            XSSFCellStyle xSSFCellStyle1 = (XSSFCellStyle)workbook.CreateCellStyle();
                            XSSFDataFormat format = (XSSFDataFormat)workbook.CreateDataFormat();
                            xSSFCellStyle1.DataFormat = format.GetFormat("yyyy/m/d");
                            cell.CellStyle = xSSFCellStyle1;
                            cell.SetCellValue(Convert.ToDateTime(dt.Rows[i][j].ToString()));
                        }
                        else
                        {
                            cell.SetCellValue(dt.Rows[i][j].ToString());
                        }

                    }

                }
            }
            //转为字节数组  
            MemoryStream stream = new MemoryStream();
            workbook.Write(stream);
            var buf = stream.ToArray();

            //保存为Excel文件  
            using (FileStream fs = new FileStream(file, FileMode.Create, FileAccess.Write))
            {
                fs.Write(buf, 0, buf.Length);
                fs.Flush();
            }
            MessageBox.Show("ok");
        }

        public DataTable SqlQuery(string strsql)
        {
            string sql = @"SELECT ITM.ITMREF_0 N'福斯物料',ITM.ITMDES1_0 N'福斯描述',YITM.YBPCNUM_0 N'客户代码',YITM.YITMREFBPC_0 N'客户料号1',YITM.YITMREFBPC2_0 N'客户料号2',YITM.YITMDESBPC_0 N'客户描述'
                          FROM FORCE.YITMBPC YITM
                          LEFT JOIN FORCE.ITMMASTER ITM on ITM.ITMREF_0=YITM.ITMREF_0 " + strsql;
            //string consql = @"server=61.152.218.58,14333;database=x3v71sql;uid=readx3;pwd=Force@54321";

            //SqlConnection conn = new SqlConnection(consql);
            SqlCommand comd = new SqlCommand(sql, conn);

            SqlDataAdapter selectadapter = new SqlDataAdapter();

            selectadapter.SelectCommand = comd;

            DataSet MyDataSet = new DataSet();


            selectadapter.SelectCommand.ExecuteNonQuery();

            selectadapter.Fill(MyDataSet);




            return MyDataSet.Tables[0];
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            filecoutsum = 0;
            filesumkm = 0.0;
            conn.Open();
            dttarget.Clear();
            this.listBox1.Items.Clear();
            sumid = 1;

            FolderBrowserDialog dialog = new FolderBrowserDialog();
            dialog.Description = "请选择文件路径";

            if (dialog.ShowDialog() == DialogResult.OK)
            {
                savePath = dialog.SelectedPath;

            }
            else
            {
                return;
            }
            var files = Directory.GetFiles(savePath, "*.xlsx");
            DirectoryInfo path = new DirectoryInfo(savePath);



            foreach (var file in files)
            {

                filecoutsum++;
                double numsums = 0.0;
                cgcount = 0;


                try
                {
                    dtsources = ExcelToTable(file);
                }
                catch
                {
                    this.listBox1.Items.Add(file + "  未成功导入，请检查excel格式");
                    continue;
                }

                string erroninfor = "";
                if (dtsources.Rows.Count <= 0)
                {
                    erroninfor = "excel 有问题 ，请检查excel！";
                    this.listBox1.Items.Add(file + erroninfor);
                    continue;
                }


                for (int i = 0; i < dtsources.Rows.Count; i++)
                {

                    if (dtsources.Rows[i][dtsources.Columns.IndexOf("标识") - 1].ToString() == "")
                    {
                        continue;
                    }


                    try
                    {
                        cgcount++;
                        numsums += Double.Parse(dtsources.Rows[i][dtsources.Columns.IndexOf("标识") + 1].ToString());
                    }
                    catch
                    {
                        cgcount--;
                        continue;
                    }

                }


                filesumkm += numsums;
                this.listBox1.Items.Add(file + "  成功导入 " + cgcount + " ,合计长度为 " + numsums + "");

                try
                {
                    MergeTable(dtsources);

                }
                catch
                {
                    this.listBox1.Items.Add(file + " 缺少列或者多列，列名有问题，请检查excel格式！ ");
                    continue;
                }
            }

            conn.Close();


            dttargetCOPY = dttarget.Copy();
            dttargetCOPY.Columns.Add("型号和规格");
            try
            {

                foreach (DataRow dr in dttargetCOPY.Rows)
                {

                    dr["型号和规格"] = dr[6].ToString() + " " + dr[7].ToString();
                }
                dttargetCOPY.DefaultView.Sort = "型号和规格 ASC,颜色 ASC,FS码 ASC";
                dttargetCOPY = dttargetCOPY.DefaultView.ToTable();
            }
            catch
            {

            }


            try
            {
                TableToExcel(dttargetCOPY, path.Parent.FullName + "//销售计划单分析auto.xlsx");
            }
            catch
            {
                this.listBox1.Items.Add(" 产生excel有问题，请检查excel！");
            }


            this.listBox1.Items.Add("  成功导入 " + filecoutsum + " ,合计总长度为 " + filesumkm + "");
        }
    }
}
