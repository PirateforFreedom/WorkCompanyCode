﻿
using NPOI.HSSF.UserModel;
using NPOI.SS.Formula.Functions;
using NPOI.SS.UserModel;
using NPOI.XSSF.UserModel;
using Org.BouncyCastle.Asn1.X509;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ForceMDIForm
{
    public partial class PerInforDistinction : Form
    {
        string savePath = "";
        DataSet dtsources;
        DataTable dttarget;

        DataTable DBdttempSecond;

        int gcount = 0;
        int cgcount = 0;
        int sumid = 1;

        int filecoutsum = 0;
        double filesumkm = 0.0;
        public PerInforDistinction()
        {
            InitializeComponent();

            InitializeTargetDT();



        }
        public void InitializeTargetDT()
        {
            dttarget = new DataTable();
            DataColumn? dc = null;
            dc = dttarget.Columns.Add("薪资发放年月", Type.GetType("System.String"));


            dc = dttarget.Columns.Add("姓名", Type.GetType("System.String"));
            dc = dttarget.Columns.Add("部门/工序", Type.GetType("System.String"));
            dc = dttarget.Columns.Add("岗位", Type.GetType("System.String"));

            dc = dttarget.Columns.Add("岗位类别", Type.GetType("System.String"));
            dc = dttarget.Columns.Add("入职日期", Type.GetType("System.String"));
            //dc = dttarget.Columns.Add("出勤时间", Type.GetType("System.String"));


            dc = dttarget.Columns.Add("岗位工资", Type.GetType("System.String"));
            dc = dttarget.Columns.Add("绩效工资", Type.GetType("System.String"));
            dc = dttarget.Columns.Add("加班工资", Type.GetType("System.String"));
            dc = dttarget.Columns.Add("病假", Type.GetType("System.String"));
            dc = dttarget.Columns.Add("事假", Type.GetType("System.String"));
            dc = dttarget.Columns.Add("奖惩", Type.GetType("System.String"));


            dc = dttarget.Columns.Add("工龄奖", Type.GetType("System.String"));
            dc = dttarget.Columns.Add("全勤奖", Type.GetType("System.String"));
            dc = dttarget.Columns.Add("绩效奖", Type.GetType("System.String"));
            dc = dttarget.Columns.Add("产量奖/计件", Type.GetType("System.String"));
            dc = dttarget.Columns.Add("夜班补贴", Type.GetType("System.String"));



            dc = dttarget.Columns.Add("妇女用品", Type.GetType("System.String"));
            dc = dttarget.Columns.Add("高温费", Type.GetType("System.String"));
            dc = dttarget.Columns.Add("补贴", Type.GetType("System.String"));
            dc = dttarget.Columns.Add("应发工资", Type.GetType("System.String"));
            dc = dttarget.Columns.Add("基本养老保险", Type.GetType("System.String"));
            dc = dttarget.Columns.Add("基本医疗保险", Type.GetType("System.String"));


            dc = dttarget.Columns.Add("失业保险", Type.GetType("System.String"));
            dc = dttarget.Columns.Add("住房公积金", Type.GetType("System.String"));
            dc = dttarget.Columns.Add("工会会费", Type.GetType("System.String"));
            dc = dttarget.Columns.Add("代扣款项", Type.GetType("System.String"));
            dc = dttarget.Columns.Add("本期预扣预缴税额", Type.GetType("System.String"));

            dc = dttarget.Columns.Add("累计个税差异调整", Type.GetType("System.String"));

            dc = dttarget.Columns.Add("实发金额", Type.GetType("System.String"));

        }

        public ICell MergedCell(ICell cell)
        {
            if(cell.IsMergedCell)
            {
                for(int i=0;i<cell.Sheet.NumMergedRegions;i++)
                {
                    var cellRange=cell.Sheet.GetMergedRegion(i);
                    if(cell.ColumnIndex>=cellRange.FirstColumn&&cell.ColumnIndex<=cellRange.LastColumn
                        &&cell.RowIndex>=cellRange.FirstRow&&cell.RowIndex<=cellRange.LastRow)
                    {
                        return cell.Sheet.GetRow(cellRange.FirstRow).GetCell(cellRange.FirstColumn);
                    }
                }
            }
            return cell;
        }
        

       
        public DataSet ExcelToTable(string file)
        {
            gcount = 0;
            DataSet dst = new DataSet();
            IWorkbook workbook;


            string fileExt = Path.GetExtension(file).ToLower();
            using (FileStream fs = new FileStream(file, FileMode.Open, FileAccess.Read))
            {
                if (fileExt == ".xlsx")
                {
                    workbook = new XSSFWorkbook(fs);
                }
                else if (fileExt == ".xls")
                {
                    workbook = new HSSFWorkbook(fs);
                }
                else
                {
                    workbook = null;
                }
                if (workbook == null)
                {
                    return null;
                }

                int SheetCount = workbook.NumberOfSheets;
                string CurrentSheetName = "sheet1";
                ISheet sheet;
                IRow header;

                for (int i = 0; i < SheetCount; i++)
                {
                    CurrentSheetName = workbook.GetSheetName(i);
                    try
                    {
                        Convert.ToInt32(CurrentSheetName);
                    }
                    catch
                    {
                        continue;
                    }
                    sheet = workbook.GetSheetAt(i);
                    DataTable dt = new DataTable(CurrentSheetName);
                    dt.Columns.Add(new DataColumn("SHEETDATE" ));
                    header = sheet.GetRow(3);
                    int tg = header.LastCellNum;
                    List<int> columns = new List<int>();
                    columns.Add(0);

                    for (int ii = 0; ii < header.LastCellNum; ii++)
                    {
                        
                        object obj;
                        obj=MergedCell(header.GetCell(ii));
                       

                        if (obj == null || obj.ToString() == string.Empty)
                        {
                            dt.Columns.Add(new DataColumn("Columns" + (ii+1).ToString()));
                        }
                        else
                           
                        dt.Columns.Add(new DataColumn(obj.ToString().Replace("\n", "").Replace(" ", "").Replace("\t", "").Replace("\r", "")));
                        columns.Add((ii+1));
                    }

                    //数据  
                    for (int ii = 4 + 1; ii < sheet.LastRowNum - 1; ii++)
                    {
                        DataRow dr = dt.NewRow();
                        bool hasValue = false;

                       
                        try
                        {
                            Convert.ToInt32(sheet.GetRow(ii).GetCell(0).ToString());
                        }
                        catch
                        {
                            continue;
                        }

                        int j = 0;
                        for (j = 0; j < columns.Count; j++)
                        {
                            if(j==0)
                            {
                                
                               DateTime dtime = DateTime.ParseExact(CurrentSheetName, "yyyyMM", System.Globalization.CultureInfo.CurrentCulture);
                                dr[j] = dtime;
                                continue;
                            }
                            
                            try
                            {
                                if (dt.Columns[j].ColumnName == "入职日期")
                                {
                                    dr[j] = sheet.GetRow(ii).GetCell(j-1).DateCellValue;
                                    hasValue = true;
                                    continue;
                                }
                            }
                            catch
                            {

                            }
                          

                            dr[j] = GetValueType(sheet.GetRow(ii).GetCell(j-1));
                            if (dr[j] != null && dr[j].ToString() != string.Empty)
                            {
                                hasValue = true;
                            }
                        }


                        if (hasValue)
                        {
                            dt.Rows.Add(dr);
                        }
                    }


                    dst.Tables.Add(dt);
                }






            }
            return dst;
        }

        private static object GetValueType(ICell cell)
        {
            if (cell == null)
                return null;
            switch (cell.CellType)
            {
                case CellType.Blank:
                    return null;
                case CellType.Boolean:
                    return cell.BooleanCellValue;
                case CellType.Numeric:
                    return cell.NumericCellValue;
                case CellType.String:
                    return cell.StringCellValue;
                case CellType.Error:
                    return cell.ErrorCellValue;
                case CellType.Formula:
                default:
                    return "=" + cell.CellFormula;
            }
        }

        public DataTable MergeTable(DataSet dst)
        {


           
            int biggerflag = 0;
            int tableint = 0;
            DataTable DBdttemp = new DataTable();
            for (int i = 0; i < dst.Tables.Count; i++)
             {
                for (int jj = 0; jj < dst.Tables[i].Columns.Count; jj++)
                {
                    if (!DBdttemp.Columns.Contains(dst.Tables[i].Columns[jj].ColumnName))
                    {
                        DBdttemp.Columns.Add(dst.Tables[i].Columns[jj].ColumnName);
                    }
                    
                }
                    
             

              }

            // DataTable DBdttemp = dst.Tables[tableint].Copy();
            
            DataTable DBdttempOrder = new DataTable();
           for (int i = 0; i < dst.Tables.Count; i++)
            {
                for (int j = 0; j < dst.Tables[i].Rows.Count; j++)
                {
                    DataRow newRow;
                    newRow = DBdttemp.NewRow();
                    for (int jj=0;jj< dst.Tables[i].Columns.Count;jj++)
                    {
                       


                        newRow[dst.Tables[i].Columns[jj].ColumnName] = dst.Tables[i].Rows[j][jj].ToString();
                        
                    }
                    DBdttemp.Rows.Add(newRow);

                }
              
            }

            DBdttempOrder = DBdttemp.Copy();


            
            DBdttempOrder.DefaultView.Sort = "姓名 ASC,SHEETDATE ASC";
                DBdttempOrder = DBdttempOrder.DefaultView.ToTable();
           


            return DBdttempOrder;





        }
        public static void TableToExcel(DataTable dt, string file)
        {


            IWorkbook workbook;
            workbook = new XSSFWorkbook();
            string fileExt = Path.GetExtension(file).ToLower();
            if (workbook == null) { return; }

            ISheet sheet = string.IsNullOrEmpty(dt.TableName) ? workbook.CreateSheet("sheet0") : workbook.CreateSheet(dt.TableName);
            //表头  
            IRow row = sheet.CreateRow(0);
            for (int i = 0; i < dt.Columns.Count; i++)
            {
                ICell cell = row.CreateCell(i);
                cell.SetCellValue(dt.Columns[i].ColumnName);
            }

            //数据  
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                IRow row1 = sheet.CreateRow(i + 1);
                for (int j = 0; j < dt.Columns.Count; j++)
                {
                    ICell cell = row1.CreateCell(j);

                    try
                    {
                        cell.SetCellValue(Convert.ToDouble(dt.Rows[i][j].ToString()));
                    }
                    catch
                    {

                        try
                        {
                           
                            if (dt.Columns[j].ColumnName == "薪资发放年月")
                            {
                                cell.SetCellValue(Convert.ToDateTime(dt.Rows[i][j].ToString()));
                                XSSFCellStyle xSSFCellStyle1 = (XSSFCellStyle)workbook.CreateCellStyle();
                                XSSFDataFormat format = (XSSFDataFormat)workbook.CreateDataFormat();
                                xSSFCellStyle1.DataFormat = format.GetFormat("yyyy/m");
                                cell.CellStyle = xSSFCellStyle1;
                            }
                            else
                            {
                                cell.SetCellValue(Convert.ToDateTime(dt.Rows[i][j].ToString()));
                                XSSFCellStyle xSSFCellStyle1 = (XSSFCellStyle)workbook.CreateCellStyle();
                                XSSFDataFormat format = (XSSFDataFormat)workbook.CreateDataFormat();
                                xSSFCellStyle1.DataFormat = format.GetFormat("yyyy/m/d");
                                cell.CellStyle = xSSFCellStyle1;
                            }
                           

                        }
                        catch
                        {
                            cell.SetCellValue(dt.Rows[i][j].ToString());
                        }


                    }

                }
            }
            //转为字节数组  
            MemoryStream stream = new MemoryStream();
            workbook.Write(stream);
            var buf = stream.ToArray();

            //保存为Excel文件  
            using (FileStream fs = new FileStream(file, FileMode.Create, FileAccess.Write))
            {
                fs.Write(buf, 0, buf.Length);
                fs.Flush();
            }
            
        }

        public void initFirstROW()
        {
            //固定标题行
            DataRow newRow;
            newRow = dttarget.NewRow();

            newRow["E"] = "/";
            newRow["销售地点"] = "SALFCY";
            newRow["订单类型"] = "SOHTYP";
            newRow["订单号"] = "SOHNUM";
            newRow["订单客户"] = "BPCORD";
            newRow["订单日期"] = "ORDDAT";
            newRow["内部计划编号"] = "CUSORDREF";
            newRow["装运地点"] = "STOFCY";
            newRow["货币"] = "CUR";
            newRow["发货地址"] = "BPAADD";
            newRow["要求发货日期"] = "DEMDLVDAT";

            newRow["装运日期"] = "SHIDAT";
            newRow["目标客户"] = "YBPCUST";
            newRow["目标客户地址"] = "YBPAADD";
            newRow["L"] = "/";
            newRow["产品"] = "ITMREF";
            newRow["客户料号1"] = "YITMREFBPC";

            newRow["销售单位"] = "SAU";
            newRow["订货数量"] = "QTY";
            newRow["毛价"] = "GROPRI";
            newRow["装运日期P"] = "SHIDAT";
            newRow["预计交货日期"] = "EXTDLVDAT";
            newRow["合同号"] = "YNUM2";

            newRow["合同行号"] = "YLIN";
            newRow["内部计划编号或合同号"] = "YCUSORDEF";

            dttarget.Rows.Add(newRow);
        }

        public DataRow Fillinfor(int i )
        {
            DataRow newRow;
            newRow = dttarget.NewRow();

            newRow["薪资发放年月"] = DBdttempSecond.Rows[i]["SHEETDATE"].ToString();
            newRow["姓名"] = DBdttempSecond.Rows[i]["姓名"].ToString();
            newRow["部门/工序"] = DBdttempSecond.Rows[i]["部门/工序"].ToString();
            newRow["岗位"] = DBdttempSecond.Rows[i]["岗位"].ToString();
            newRow["岗位类别"] = DBdttempSecond.Rows[i]["岗位类别"].ToString();
            newRow["入职日期"] = DBdttempSecond.Rows[i]["入职日期"].ToString();

            //newRow["出勤时间"] = DBdttempSecond.Rows[i]["出勤时间"].ToString();
            newRow["岗位工资"] = DBdttempSecond.Rows[i]["岗位工资"].ToString();
            newRow["绩效工资"] = DBdttempSecond.Rows[i]["绩效工资"].ToString();
            newRow["加班工资"] = DBdttempSecond.Rows[i]["加班工资"].ToString();
            newRow["病假"] = DBdttempSecond.Rows[i]["病假"].ToString();

            newRow["事假"] = DBdttempSecond.Rows[i]["事假"].ToString();
            newRow["奖惩"] = DBdttempSecond.Rows[i]["奖惩"].ToString();
            try
            {
                newRow["工龄奖"] = DBdttempSecond.Rows[i]["工龄奖"].ToString();
                newRow["全勤奖"] = DBdttempSecond.Rows[i]["全勤奖"].ToString();
                newRow["绩效奖"] = DBdttempSecond.Rows[i]["绩效奖"].ToString();
                newRow["产量奖/计件"] = DBdttempSecond.Rows[i]["产量奖/计件"].ToString();
                newRow["夜班补贴"] = DBdttempSecond.Rows[i]["夜班补贴"].ToString();
            }
            catch
            {
                newRow["工龄奖"] = "";
                newRow["全勤奖"] = "";
                newRow["绩效奖"] = "";
                newRow["产量奖/计件"] = "";
                newRow["夜班补贴"] = "";
            }
            
           

            newRow["妇女用品"] = DBdttempSecond.Rows[i]["妇女用品"].ToString();
            newRow["高温费"] = DBdttempSecond.Rows[i]["高温费"].ToString();
            newRow["补贴"] = DBdttempSecond.Rows[i]["补贴"].ToString();

            newRow["应发工资"] = DBdttempSecond.Rows[i]["应发工资"].ToString();
            newRow["基本养老保险"] = DBdttempSecond.Rows[i]["基本养老保险"].ToString();
            newRow["基本医疗保险"] = DBdttempSecond.Rows[i]["基本医疗保险"].ToString();
            newRow["失业保险"] = DBdttempSecond.Rows[i]["失业保险"].ToString();
            newRow["住房公积金"] = DBdttempSecond.Rows[i]["住房公积金"].ToString();

            newRow["工会会费"] = DBdttempSecond.Rows[i]["工会会费"].ToString();
            newRow["代扣款项"] = DBdttempSecond.Rows[i]["代扣款项"].ToString();
            newRow["本期预扣预缴税额"] = DBdttempSecond.Rows[i]["本期预扣预缴税额"].ToString();
            newRow["累计个税差异调整"] = DBdttempSecond.Rows[i]["累计个税差异调整"].ToString();
            newRow["实发金额"] = DBdttempSecond.Rows[i]["实发金额"].ToString();

            return newRow;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            
            this.listBox1.Items.Clear();
            FolderBrowserDialog dialog = new FolderBrowserDialog();
            dialog.Description = "请选择文件路径";
            dttarget.Clear();
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                savePath = dialog.SelectedPath;

            }
            else
            {
                return;
            }
            var files = Directory.GetFiles(savePath, "*.xlsx");
            DirectoryInfo path = new DirectoryInfo(savePath);





            try
            {
                dtsources = ExcelToTable(files[0].ToString());
            }
            catch
            {
                this.listBox1.Items.Add("NO,读取excel文件有问题，请检查文件格式！！！！！！！！！！！！");
                return;
            }
            this.listBox1.Items.Add("YES,读取excel文件成功");
            try
            {
                DBdttempSecond = MergeTable(dtsources);
            } 
            catch
            {
                this.listBox1.Items.Add("NO,合并excel文件有问题，请检查文件格式！！！！！！！！！！！！");
                return;
           }
            this.listBox1.Items.Add("YES,合并excel文件成功");
            try
            {
                string flagtemp = "1";
                flagtemp = DBdttempSecond.Rows[0]["姓名"].ToString();
                for (int i = 0; i < DBdttempSecond.Rows.Count; i++)
                {
                    if(DBdttempSecond.Rows[i]["姓名"].ToString()==null|| DBdttempSecond.Rows[i]["姓名"].ToString() =="")
                    {
                        this.listBox1.Items.Add("NO,生成excel文件有问题，请检查文件格式！！！！！！！！！！！！");
                        return;
                    }
                    
                    if (flagtemp == DBdttempSecond.Rows[i]["姓名"].ToString())
                    {
                        dttarget.Rows.Add(Fillinfor(i));
                        flagtemp = DBdttempSecond.Rows[i]["姓名"].ToString();
                        continue;
                    }
                    TableToExcel(dttarget, path.FullName + "//" + flagtemp + ".xlsx");
                    dttarget.Clear();
                    flagtemp = DBdttempSecond.Rows[i]["姓名"].ToString();
                    dttarget.Rows.Add(Fillinfor(i));

                }
            }
            catch
            {
                this.listBox1.Items.Add("NO,生成excel文件有问题，请检查文件格式！！！！！！！！！！！！");
                return;
            }
            label2.Text = path.FullName;
            this.listBox1.Items.Add("YES,生成excel文件成功");
            MessageBox.Show("ok");









        }

        


    }
}
