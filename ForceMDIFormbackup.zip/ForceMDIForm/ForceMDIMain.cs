﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ForceMDIForm
{
    public partial class ForceMDIMain : Form
    {
        private int childFormNumber = 0;

        public ForceMDIMain()
        {
            InitializeComponent();
        }

        private void ShowCFSalesOTForm(object sender, EventArgs e)
        {
            SalesOrdersTransform CFSalesOT= new SalesOrdersTransform();
            CFSalesOT.MdiParent = this;
           CFSalesOT.Show();
        }

        private void ShowCFSalesPAForm(object sender, EventArgs e)
        {
            //SalePlanAnalysis CFSalesPA = new SalePlanAnalysis();
             //CFSalesPA.MdiParent = this;
             //CFSalesPA.Show();

           // SalesOrderAnalysis CFSalesOA = new SalesOrderAnalysis();
           // CFSalesOA.MdiParent = this;
           // CFSalesOA.Show();
        }

        private void ShowCFSalesOAForm(object sender, EventArgs e)
        {
           SalesOrderAnalysis CFSalesOA = new SalesOrderAnalysis();
           CFSalesOA.MdiParent = this;
           CFSalesOA.Show();
        }

        private void ShowPersonInforDForm(object sender, EventArgs e)
        {
            //PerInforDistinction PersonInforD = new PerInforDistinction();
            //PersonInforD.MdiParent = this;
            ///PersonInforD.Show();
        }


    }
}
