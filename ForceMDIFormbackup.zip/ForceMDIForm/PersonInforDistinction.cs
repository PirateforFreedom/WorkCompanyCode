﻿using NPOI.HSSF.UserModel;
using NPOI.SS.Formula.Functions;
using NPOI.SS.UserModel;
using NPOI.XSSF.UserModel;
using Org.BouncyCastle.Asn1.X509;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ForceMDIForm
{
    public partial class PersonInforDistinction : Form
    {
        string savePath = "";
        DataSet dtsources;
        DataTable dttarget;
       
        DataTable DBdttempSecond;

        int gcount = 0;
        int cgcount = 0;
        int sumid = 1;

        int filecoutsum = 0;
        double filesumkm = 0.0;
        public PersonInforDistinction()
        {
            InitializeComponent();





        }
        public void InitializeTargetDT()
        {
            dttarget = new DataTable();
            DataColumn? dc = null;
            dc = dttarget.Columns.Add("E", Type.GetType("System.String"));


            dc = dttarget.Columns.Add("销售地点", Type.GetType("System.String"));
            dc = dttarget.Columns.Add("订单类型", Type.GetType("System.String"));
            dc = dttarget.Columns.Add("订单号", Type.GetType("System.String"));

            dc = dttarget.Columns.Add("订单客户", Type.GetType("System.String"));
            dc = dttarget.Columns.Add("订单日期", Type.GetType("System.String"));
            dc = dttarget.Columns.Add("内部计划编号", Type.GetType("System.String"));


            dc = dttarget.Columns.Add("装运地点", Type.GetType("System.String"));
            dc = dttarget.Columns.Add("货币", Type.GetType("System.String"));
            dc = dttarget.Columns.Add("发货地址", Type.GetType("System.String"));
            dc = dttarget.Columns.Add("要求发货日期", Type.GetType("System.String"));
            dc = dttarget.Columns.Add("装运日期", Type.GetType("System.String"));
            dc = dttarget.Columns.Add("目标客户", Type.GetType("System.String"));


            dc = dttarget.Columns.Add("目标客户地址", Type.GetType("System.String"));
            dc = dttarget.Columns.Add("L", Type.GetType("System.String"));
            dc = dttarget.Columns.Add("产品", Type.GetType("System.String"));
            dc = dttarget.Columns.Add("客户料号1", Type.GetType("System.String"));
            dc = dttarget.Columns.Add("销售单位", Type.GetType("System.String"));
            dc = dttarget.Columns.Add("订货数量", Type.GetType("System.String"));


            dc = dttarget.Columns.Add("毛价", Type.GetType("System.String"));
            dc = dttarget.Columns.Add("装运日期P", Type.GetType("System.String"));
            dc = dttarget.Columns.Add("预计交货日期", Type.GetType("System.String"));
            dc = dttarget.Columns.Add("合同号", Type.GetType("System.String"));
            dc = dttarget.Columns.Add("合同行号", Type.GetType("System.String"));

            dc = dttarget.Columns.Add("内部计划编号或合同号", Type.GetType("System.String"));



        }
        public DataSet ExcelToTable(string file)
        {
            gcount = 0;
            DataSet dst = new DataSet();
            IWorkbook workbook;
            
         
            string fileExt = Path.GetExtension(file).ToLower();
            using (FileStream fs = new FileStream(file, FileMode.Open, FileAccess.Read))
            {
                if (fileExt == ".xlsx")
                {
                    workbook = new XSSFWorkbook(fs);
                }
                else if (fileExt == ".xls")
                {
                    workbook = new HSSFWorkbook(fs);
                }
                else
                {
                    workbook = null;
                }
                if (workbook == null)
                {
                    return null;
                }

                int SheetCount = workbook.NumberOfSheets;
                string CurrentSheetName="sheet1";
                ISheet sheet;
                IRow header;
              
                for (int i = 0; i < SheetCount; i++)
                {
                    CurrentSheetName = workbook.GetSheetName(i);
                    sheet = workbook.GetSheetAt(i);
                    DataTable dt = new DataTable(CurrentSheetName);
                    header = sheet.GetRow(3);
                    List<int> columns = new List<int>();
                  
                  
                    for (int ii = 0; ii < header.LastCellNum-1; ii++)
                    {
                        object obj;
                        if (ii<2||(ii>=16&&ii<=20)||(ii>=24&&ii<=25))
                        {
                            obj = GetValueType(sheet.GetRow(2).GetCell(ii));
                        }
                        else
                        {
                            obj = GetValueType(header.GetCell(ii));
                        }
                       
                        if (obj == null || obj.ToString() == string.Empty)
                        {
                            dt.Columns.Add(new DataColumn("Columns" + ii.ToString()));
                        }
                        else
                            dt.Columns.Add(new DataColumn(obj.ToString()));
                        columns.Add(ii);
                    }

                    //数据  
                    for (int ii = 4 + 1; ii < sheet.LastRowNum-1 ; ii++)
                    {
                        DataRow dr = dt.NewRow();
                        bool hasValue = false;
                       // gcount++;


                   
                        int j = 0;
                        for (j = 0; j < columns.Count; j++)
                        {
                            
                            try
                            {
                                if (dt.Columns[j].ColumnName == "入职日期" )
                                {
                                    dr[j] = sheet.GetRow(ii).GetCell(j).DateCellValue;
                                    hasValue = true;
                                    continue;
                                }
                            }
                            catch
                            {

                            }
                           // try
                           // {
                               // if (sheet.GetRow(ii).GetCell(j).CellType == CellType.Formula)
                               // {
                                //    sheet.GetRow(ii).GetCell(j).SetCellType(CellType.String);
                                 //   dr[j] = sheet.GetRow(ii).GetCell(j).StringCellValue;
                                  //  hasValue = true;
                                   // continue;
                               // }
                          //  }
                           // catch
                           // {

                          //  }


                            dr[j] = GetValueType(sheet.GetRow(ii).GetCell(j));
                            if (dr[j] != null && dr[j].ToString() != string.Empty)
                            {
                                hasValue = true;
                            }
                        }


                        if (hasValue)
                        {
                            dt.Rows.Add(dr);
                        }
                    }


                   dst.Tables.Add(dt);
                }
             



                
                
            }
            return dst;
        }

        private static object GetValueType(ICell cell)
        {
            if (cell == null)
                return null;
            switch (cell.CellType)
            {
                case CellType.Blank:
                    return null;
                case CellType.Boolean:
                    return cell.BooleanCellValue;
                case CellType.Numeric:
                    return cell.NumericCellValue;
                case CellType.String:
                    return cell.StringCellValue;
                case CellType.Error:
                    return cell.ErrorCellValue;
                case CellType.Formula:
                default:
                    return "=" + cell.CellFormula;
            }
        }

        public DataTable  MergeTable(DataSet dst)
        {


            DataTable  DBdttemp = dst.Tables[0].Clone();
            DataColumn? dc = null;
            DBdttemp.Columns.Add("SHEETDATE", Type.GetType("System.String"));
            for (int i = 0; i < dst.Tables.Count; i++)
            {
                for (int j = 0; j < dst.Tables[i].Rows.Count; j++)
                {
                    int m = 0;
                    for (m = 0; m < dst.Tables[i].Columns.Count; m++)
                    {
                        DBdttemp.Rows[j][m] = dst.Tables[i].Rows[j][m];


                    }
                    DBdttemp.Rows[j][m + 1] = dst.Tables[i].TableName;
                }

            }




            return DBdttemp;





        }
        public static void TableToExcel(DataTable dt, string file)
        {


            IWorkbook workbook;
            workbook = new XSSFWorkbook();
            string fileExt = Path.GetExtension(file).ToLower();
            if (workbook == null) { return; }

            ISheet sheet = string.IsNullOrEmpty(dt.TableName) ? workbook.CreateSheet("sheet0") : workbook.CreateSheet(dt.TableName);
            //表头  
            IRow row = sheet.CreateRow(0);
            for (int i = 0; i < dt.Columns.Count; i++)
            {
                ICell cell = row.CreateCell(i);
                cell.SetCellValue(dt.Columns[i].ColumnName);
            }

            //数据  
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                IRow row1 = sheet.CreateRow(i + 1);
                for (int j = 0; j < dt.Columns.Count; j++)
                {
                    ICell cell = row1.CreateCell(j);

                    try
                    {
                        cell.SetCellValue(Convert.ToDouble(dt.Rows[i][j].ToString()));
                    }
                    catch
                    {

                        try
                        {
                            cell.SetCellValue(Convert.ToDateTime(dt.Rows[i][j].ToString()));
                            XSSFCellStyle xSSFCellStyle1 = (XSSFCellStyle)workbook.CreateCellStyle();
                            XSSFDataFormat format = (XSSFDataFormat)workbook.CreateDataFormat();
                            xSSFCellStyle1.DataFormat = format.GetFormat("yyyy/m/d");
                            cell.CellStyle = xSSFCellStyle1;

                        }
                        catch
                        {
                            cell.SetCellValue(dt.Rows[i][j].ToString());
                        }


                    }

                }
            }
            //转为字节数组  
            MemoryStream stream = new MemoryStream();
            workbook.Write(stream);
            var buf = stream.ToArray();

            //保存为Excel文件  
            using (FileStream fs = new FileStream(file, FileMode.Create, FileAccess.Write))
            {
                fs.Write(buf, 0, buf.Length);
                fs.Flush();
            }
            MessageBox.Show("ok");
        }

        public void initFirstROW()
        {
            //固定标题行
            DataRow newRow;
            newRow = dttarget.NewRow();

            newRow["E"] = "/";
            newRow["销售地点"] = "SALFCY";
            newRow["订单类型"] = "SOHTYP";
            newRow["订单号"] = "SOHNUM";
            newRow["订单客户"] = "BPCORD";
            newRow["订单日期"] = "ORDDAT";
            newRow["内部计划编号"] = "CUSORDREF";
            newRow["装运地点"] = "STOFCY";
            newRow["货币"] = "CUR";
            newRow["发货地址"] = "BPAADD";
            newRow["要求发货日期"] = "DEMDLVDAT";

            newRow["装运日期"] = "SHIDAT";
            newRow["目标客户"] = "YBPCUST";
            newRow["目标客户地址"] = "YBPAADD";
            newRow["L"] = "/";
            newRow["产品"] = "ITMREF";
            newRow["客户料号1"] = "YITMREFBPC";

            newRow["销售单位"] = "SAU";
            newRow["订货数量"] = "QTY";
            newRow["毛价"] = "GROPRI";
            newRow["装运日期P"] = "SHIDAT";
            newRow["预计交货日期"] = "EXTDLVDAT";
            newRow["合同号"] = "YNUM2";

            newRow["合同行号"] = "YLIN";
            newRow["内部计划编号或合同号"] = "YCUSORDEF";

            dttarget.Rows.Add(newRow);
        }
        private void button1_Click(object sender, EventArgs e)
        {
            //filecoutsum = 0;
            //filesumkm = 0.0;
           // InitializeTargetDT();

           // dttarget.Clear();
            //initFirstROW();
            this.listBox1.Items.Clear();
            //sumid = 1;

            FolderBrowserDialog dialog = new FolderBrowserDialog();
            dialog.Description = "请选择文件路径";

            if (dialog.ShowDialog() == DialogResult.OK)
            {
                savePath = dialog.SelectedPath;

            }
            else
            {
                return;
            }
            var files = Directory.GetFiles(savePath, "*.xlsx");
            DirectoryInfo path = new DirectoryInfo(savePath);



            foreach (var file in files)
            {

                //filecoutsum++;
                //double numsums = 0.0;
                //cgcount = 0;


                // try
                // {
                dtsources = ExcelToTable(file);
                //}
                //catch
                // {
                //  this.listBox1.Items.Add(file + "  未成功导入，请检查excel格式");
                //  continue;
                // }

                //string erroninfor = "";
                //if (dtsources.Rows.Count <= 0)
                //{
                // erroninfor = "excel 有问题 ，请检查excel！";
                // this.listBox1.Items.Add(file + erroninfor);
                //continue;
                //}



                // try
                // {
                DBdttempSecond=MergeTable(dtsources);

               // }
               // catch
               // {
               //     this.listBox1.Items.Add(file + " 缺少列或者多列，列名有问题，请检查excel格式！ ");
              //      continue;
              //  }
           }







           // try
            //{
                //TableToExcel(dttarget, path.Parent.FullName + "//销售部_销售订单模板数据auto.xlsx");
               // label2.Text = path.Parent.FullName + "//销售部_销售订单模板数据auto.xlsx";
           // }
           // catch
            //{
              //  this.listBox1.Items.Add(" 产生excel有问题，请检查excel！");
          //  }


           // this.listBox1.Items.Add("  成功导入 " + filecoutsum + " ,合计总长度为 " + filesumkm + "");

        }

        
    }
}
