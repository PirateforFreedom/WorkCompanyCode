﻿namespace ForceMDIForm
{
    partial class ForceMDIMain
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ForceMDIMain));
            this.menuStrip = new System.Windows.Forms.MenuStrip();
            this.fileMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.newToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.销售订单转换v10ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.销售订单分析v10ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.生产计划组程式ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.订单相关ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.销售计划单分析v20ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.工厂人事部程式ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.人员信息相关ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.人事信息区分v10ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolTip = new System.Windows.Forms.ToolTip(this.components);
            this.menuStrip.SuspendLayout();
            this.statusStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip
            // 
            this.menuStrip.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileMenu,
            this.生产计划组程式ToolStripMenuItem,
            this.工厂人事部程式ToolStripMenuItem});
            this.menuStrip.Location = new System.Drawing.Point(0, 0);
            this.menuStrip.Name = "menuStrip";
            this.menuStrip.Padding = new System.Windows.Forms.Padding(9, 3, 0, 3);
            this.menuStrip.Size = new System.Drawing.Size(1280, 30);
            this.menuStrip.TabIndex = 0;
            this.menuStrip.Text = "MenuStrip";
            // 
            // fileMenu
            // 
            this.fileMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newToolStripMenuItem,
            this.toolStripSeparator3});
            this.fileMenu.ImageTransparentColor = System.Drawing.SystemColors.ActiveBorder;
            this.fileMenu.Name = "fileMenu";
            this.fileMenu.Size = new System.Drawing.Size(113, 24);
            this.fileMenu.Text = "销售部门程式";
            // 
            // newToolStripMenuItem
            // 
            this.newToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.销售订单转换v10ToolStripMenuItem,
            this.销售订单分析v10ToolStripMenuItem});
            this.newToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Black;
            this.newToolStripMenuItem.Name = "newToolStripMenuItem";
            this.newToolStripMenuItem.Size = new System.Drawing.Size(152, 26);
            this.newToolStripMenuItem.Text = "订单相关";
            // 
            // 销售订单转换v10ToolStripMenuItem
            // 
            this.销售订单转换v10ToolStripMenuItem.Name = "销售订单转换v10ToolStripMenuItem";
            this.销售订单转换v10ToolStripMenuItem.Size = new System.Drawing.Size(212, 26);
            this.销售订单转换v10ToolStripMenuItem.Text = "销售订单转换v1.0";
            this.销售订单转换v10ToolStripMenuItem.Click += new System.EventHandler(this.ShowCFSalesOTForm);
            // 
            // 销售订单分析v10ToolStripMenuItem
            // 
            this.销售订单分析v10ToolStripMenuItem.Name = "销售订单分析v10ToolStripMenuItem";
            this.销售订单分析v10ToolStripMenuItem.Size = new System.Drawing.Size(212, 26);
            this.销售订单分析v10ToolStripMenuItem.Text = "销售订单分析v1.0";
            this.销售订单分析v10ToolStripMenuItem.Click += new System.EventHandler(this.ShowCFSalesOAForm);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(149, 6);
            // 
            // 生产计划组程式ToolStripMenuItem
            // 
            this.生产计划组程式ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.订单相关ToolStripMenuItem});
            this.生产计划组程式ToolStripMenuItem.Name = "生产计划组程式ToolStripMenuItem";
            this.生产计划组程式ToolStripMenuItem.Size = new System.Drawing.Size(128, 24);
            this.生产计划组程式ToolStripMenuItem.Text = "生产计划组程式";
            // 
            // 订单相关ToolStripMenuItem
            // 
            this.订单相关ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.销售计划单分析v20ToolStripMenuItem});
            this.订单相关ToolStripMenuItem.Name = "订单相关ToolStripMenuItem";
            this.订单相关ToolStripMenuItem.Size = new System.Drawing.Size(152, 26);
            this.订单相关ToolStripMenuItem.Text = "订单相关";
            // 
            // 销售计划单分析v20ToolStripMenuItem
            // 
            this.销售计划单分析v20ToolStripMenuItem.Name = "销售计划单分析v20ToolStripMenuItem";
            this.销售计划单分析v20ToolStripMenuItem.Size = new System.Drawing.Size(227, 26);
            this.销售计划单分析v20ToolStripMenuItem.Text = "销售计划单分析v2.1";
            this.销售计划单分析v20ToolStripMenuItem.Click += new System.EventHandler(this.ShowCFSalesPAForm);
            // 
            // 工厂人事部程式ToolStripMenuItem
            // 
            this.工厂人事部程式ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.人员信息相关ToolStripMenuItem});
            this.工厂人事部程式ToolStripMenuItem.Name = "工厂人事部程式ToolStripMenuItem";
            this.工厂人事部程式ToolStripMenuItem.Size = new System.Drawing.Size(128, 24);
            this.工厂人事部程式ToolStripMenuItem.Text = "工厂人事部程式";
            // 
            // 人员信息相关ToolStripMenuItem
            // 
            this.人员信息相关ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.人事信息区分v10ToolStripMenuItem});
            this.人员信息相关ToolStripMenuItem.Name = "人员信息相关ToolStripMenuItem";
            this.人员信息相关ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.人员信息相关ToolStripMenuItem.Text = "人员信息相关";
            // 
            // 人事信息区分v10ToolStripMenuItem
            // 
            this.人事信息区分v10ToolStripMenuItem.Name = "人事信息区分v10ToolStripMenuItem";
            this.人事信息区分v10ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.人事信息区分v10ToolStripMenuItem.Text = "人事信息区分v1.0";
            this.人事信息区分v10ToolStripMenuItem.Click += new System.EventHandler(this.ShowPersonInforDForm);
            // 
            // statusStrip
            // 
            this.statusStrip.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.statusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel});
            this.statusStrip.Location = new System.Drawing.Point(0, 717);
            this.statusStrip.Name = "statusStrip";
            this.statusStrip.Padding = new System.Windows.Forms.Padding(2, 0, 21, 0);
            this.statusStrip.Size = new System.Drawing.Size(1280, 26);
            this.statusStrip.TabIndex = 2;
            this.statusStrip.Text = "StatusStrip";
            // 
            // toolStripStatusLabel
            // 
            this.toolStripStatusLabel.Name = "toolStripStatusLabel";
            this.toolStripStatusLabel.Size = new System.Drawing.Size(39, 20);
            this.toolStripStatusLabel.Text = "状态";
            // 
            // ForceMDIMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1280, 743);
            this.Controls.Add(this.statusStrip);
            this.Controls.Add(this.menuStrip);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip;
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "ForceMDIMain";
            this.Text = "福斯Plugins系统v1.1";
            this.menuStrip.ResumeLayout(false);
            this.menuStrip.PerformLayout();
            this.statusStrip.ResumeLayout(false);
            this.statusStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        #endregion


        private System.Windows.Forms.MenuStrip menuStrip;
        private System.Windows.Forms.StatusStrip statusStrip;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel;
        private System.Windows.Forms.ToolStripMenuItem fileMenu;
        private System.Windows.Forms.ToolStripMenuItem newToolStripMenuItem;
        private System.Windows.Forms.ToolTip toolTip;
        private ToolStripMenuItem 销售订单转换v10ToolStripMenuItem;
        private ToolStripMenuItem 生产计划组程式ToolStripMenuItem;
        private ToolStripMenuItem 订单相关ToolStripMenuItem;
        private ToolStripMenuItem 销售计划单分析v20ToolStripMenuItem;
        private ToolStripMenuItem 销售订单分析v10ToolStripMenuItem;
        private ToolStripMenuItem 工厂人事部程式ToolStripMenuItem;
        private ToolStripMenuItem 人员信息相关ToolStripMenuItem;
        private ToolStripMenuItem 人事信息区分v10ToolStripMenuItem;
    }
}



