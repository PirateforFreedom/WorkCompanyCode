﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ForceMDIForm
{
   
    public class DBOperation
    {
        string consql = @"server=61.152.218.58,14333;database=x3v71sql;uid=readx3;pwd=Force@54321";
        SqlConnection conn;
       public DBOperation()
        {
            conn = new SqlConnection(consql);
            conn.Open();

        }
        public DataTable SqlQuery(string strsql)
        {
            string sql = @"SELECT ITM.ITMREF_0 N'福斯物料',ITM.ITMDES1_0 N'福斯描述',YITM.YBPCNUM_0 N'客户代码',YITM.YITMREFBPC_0 N'客户料号1',YITM.YITMREFBPC2_0 N'客户料号2',YITM.YITMDESBPC_0 N'客户描述'
                          FROM FORCE.YITMBPC YITM
                          LEFT JOIN FORCE.ITMMASTER ITM on ITM.ITMREF_0=YITM.ITMREF_0 " + strsql;
          
         
            
             SqlCommand comd = new SqlCommand(sql, conn);

            SqlDataAdapter selectadapter = new SqlDataAdapter();

            selectadapter.SelectCommand = comd;

            DataSet MyDataSet = new DataSet();


            selectadapter.SelectCommand.ExecuteNonQuery();

            selectadapter.Fill(MyDataSet);



            return MyDataSet.Tables[0];
           
        }

        public void closedbcon()
        {
            conn.Close(); 
        }
    }
}
